def add_numbers(num1, num2):
    result = num1 + num2
    return f'The Sum is: {result}'


def subtract_numbers(num1, num2):
    result = num1 - num2
    return f'The Difference is: {result}'


def multiply_numbers(num1, num2):
    result = num1 * num2
    return f'The Product is: {result}'


def divide_numbers_float(num1, num2):
    result = num1 / num2
    return f'The Divide Float is: {result}'


def divide_numbers_floor(num1, num2):
    result = num1 // num2
    return f'The Divide Floor is: {result}'


def mode_numbers(num1, num2):
    result = num1 % num2
    return f'The Mode is: {result}'


def power_numbers(num1, num2):
    result = num1 ** num2
    return f'The Power is: {result}'
